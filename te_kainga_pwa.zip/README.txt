# Te Kāinga PWA

This is the PWA version of Te Kāinga MAX.

Files:
- index.html — the Te Kāinga app
- manifest.json — installable app metadata
- sw.js — offline/service-worker support
- icons/icon.svg — app icon

Important: a PWA normally must be served over HTTPS (or localhost). Opening index.html directly with file:// will not provide full PWA installation/service-worker functionality.

Recommended deployment: upload this folder to a static HTTPS host. Once opened in Chrome, use the Install button in the address bar or the in-page Install Te Kāinga button, then right-click the app in the Launcher and choose Pin to shelf.
